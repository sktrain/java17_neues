package sk.train.p1;


public class Main {

    public static void main(String[] args) {

    	//problemfrei
        System.out.println("Hello World!");

        //interne API nutzen
        System.out.println(com.sun.awt.AWTUtilities.isWindowShapingSupported());  
        System.out.println(java.util.Arrays.toString(jdk.internal.misc.VM.getRuntimeArguments()));
        //Abhilfe f�r Compiler: --add-exports java.desktop/com.sun.awt=ALL-UNNAMED
        //bzw: --add-exports java.base/jdk.internal.misc=ALL-UNNAMED 
        //f�r VM ebenfalls notwendig
        //allerdings f�gt Eclipse die Optionen des Compilers auch dem VM-Aufruf automatisch hinzu 

        //nutzen von JAXB, nicht mehr im Basis-Modul-Satz
        //JAXB mit Pair nutzen
        javax.xml.bind.JAXB.marshal(new Pair(), System.out);
        //Abhilfe f�r Compiler: --add-modules java.xml.bind  f�r Compiler
        //Abhilfe f�r VM: --add-modules java.xml.bind, falls NoClassDefFoundError
        //bei Eclipse nicht n�tig
        
        javax.xml.bind.JAXB.marshal("Hallo", System.out);
        
        //zus�tzlich f�r VM weil JAXB Reflection nutzt: --add-opens java.base/java.lang=java.xml.bind



    }
}

class Pair{
	
	private int x;
	private int y;
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
}

