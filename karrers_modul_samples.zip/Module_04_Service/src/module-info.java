module module04_Service {
	exports sk.train.service;
	requires java.logging;
	
}