module module_04_App {	
	requires module04_Service;
	requires java.desktop;
}