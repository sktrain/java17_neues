module module_04_App {	
	requires module04_Service;
	requires java.se;
	//requires module_04_ServiceImpl;
	//requires java.desktop;
}