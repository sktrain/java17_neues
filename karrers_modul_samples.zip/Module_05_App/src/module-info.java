module module_05_App {	
	requires module05_Service;
	requires java.desktop;
}