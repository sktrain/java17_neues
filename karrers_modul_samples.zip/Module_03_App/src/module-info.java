module module_03_App {	
	requires module03_Service;
}