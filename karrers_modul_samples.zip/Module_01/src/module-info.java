
module module_01 {
	
	requires java.base;
	exports sk.train ;
}