module module05_Service {
	exports sk.train.service;
	requires java.logging;
	
}