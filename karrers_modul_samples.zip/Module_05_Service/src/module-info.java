//open 
module module05_Service {
	exports sk.train.service;
	//exports sk.train.service.impl;
	requires java.logging;
	//opens sk.train.service.impl;
	
}