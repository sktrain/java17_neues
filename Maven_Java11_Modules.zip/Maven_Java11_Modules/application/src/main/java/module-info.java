module application {
	
	requires service;
	
	
}