package sk.train.mehrfachvererbung;

public class BrownEyes {	
	public String getColor() {
		return "brown";
	}
}
