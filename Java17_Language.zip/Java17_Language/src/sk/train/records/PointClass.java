package sk.train.records;

public class PointClass {
	
	

}
