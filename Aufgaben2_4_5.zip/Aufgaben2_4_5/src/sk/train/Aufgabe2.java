package sk.train;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Aufgabe2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	private static void collectionsExampleJdk8() {
		final List<String> names = Arrays.asList("Tim", "Tom", "Mike");
		System.out.println(names);
		final Set<Integer> numbers = new TreeSet<>();
		numbers.add(1);
		numbers.add(3);
		numbers.add(4);
		numbers.add(2);
		System.out.println(numbers);
		final Map<Integer, String> mapping = new HashMap<>();
		mapping.put(5, "five");
		mapping.put(6, "six");
		mapping.put(7, "seven");
		System.out.println(mapping);
		
		List<String> li1 = List.of("Tim", "Tom", "Mike");
		List<String> li2 = List.copyOf(names);
		System.out.println(li1.getClass());
		
		Set<Integer> si = Set.copyOf(numbers);
		
		Map<Integer, String> mi = Map.of(5, "five",  6, "six", 7, "seven");
		mi = Map.ofEntries(Map.entry(5, "five"));
		mi = Map.copyOf(mapping);
		
	}

}
