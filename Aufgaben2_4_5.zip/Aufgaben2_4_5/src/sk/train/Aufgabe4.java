package sk.train;

import java.util.Optional;
import java.util.stream.Stream;

public class Aufgabe4 {
	public static void main(String[] args) {

	}

	private static void findJdk8() {
		final Optional<Person> opt = findPersonByName("Tim");
//		if (opt.isPresent()) {
//			doHappyCase(opt.get());
//		} else {
//			doErrorCase();
//		}
		//opt.ifPresentOrElse(Aufgabe4::doHappyCase, Aufgabe4::doErrorCase);
		opt.ifPresentOrElse(person -> doHappyCase(person), () -> doErrorCase());
		
		
		final Optional<Person> opt2 = findPersonByName("UNKNOWN");
//		if (opt2.isPresent()) {
//			doHappyCase(opt2.get());
//		} else {
//			doErrorCase();
//		}
		opt2.ifPresentOrElse(Aufgabe4::doHappyCase, Aufgabe4::doErrorCase);
		
	}

	private static Optional<Person> findPersonByName(final String searchFor) {
		final Stream<Person> persons = Stream.of(new Person("Mike"), new Person("Tim"), new Person("Tom"));
		return persons.filter(person -> person.getName().equals(searchFor)).findFirst();
	}

	private static void doHappyCase(final Person person) {
		System.out.println("Result: " + person);
	}

	private static void doErrorCase() {
		System.out.println("not found");
	}

	static class Person {
		private final String name;

		public Person(final String name) {
			this.name = name;
		}

		public String getName() {
			// TODO Auto-generated method stub
			return name;
		}
//...
	}
}
