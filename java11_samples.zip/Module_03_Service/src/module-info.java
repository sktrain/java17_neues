module module03_Service {
	exports sk.train.service to module_03_App;
	requires java.base;
	
}