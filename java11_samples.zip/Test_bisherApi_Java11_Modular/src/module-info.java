module test_bisherApi_Java11_Modular {
	requires java.xml.bind;
	opens sk.train.p1 to java.xml.bind;
}