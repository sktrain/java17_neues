Maven-Projekt auf Basis Java 11 f�r Java11-Sample-Code
