package appl.a_classpath;

import book.Book;

public class ProblemClasspathOrderApp {

    public static void main(String[] args) {
        // problem 1/5
        System.out.println(new Book("1", "The Book", 2000, "Author"));
    }

}
