package sk.train.service.impl;

public class SimpleBean {
	
	private String s = "Karrer";

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}
	
	

}
