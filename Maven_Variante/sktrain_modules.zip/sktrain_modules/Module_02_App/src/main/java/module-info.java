module module_02_App {
	
	requires module02_Service;
	
}