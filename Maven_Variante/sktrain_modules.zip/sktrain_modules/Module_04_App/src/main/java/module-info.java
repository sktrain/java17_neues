module module_04_App {	
	
	requires module04_Service;
	requires java.se;   //Aggregator-Modul statt java.desktop und weitere ...
	//requires module_04_ServiceImpl;
	//requires java.desktop;
}