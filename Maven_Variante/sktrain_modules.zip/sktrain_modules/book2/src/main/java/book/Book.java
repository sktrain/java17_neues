package book;

public class Book {

    @SuppressWarnings("unused")
    public Book(String isbn, String title, Integer year, String author) {
    }

}
