Übungen:	Java17 Sprach Features

(Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom September 2024
+ Jupiter-Dependencies)