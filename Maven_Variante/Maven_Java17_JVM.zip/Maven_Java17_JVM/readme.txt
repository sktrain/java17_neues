Java17 Runntime Samples

(Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom September 2024
+ Jupiter-Dependencies)