Lösungen zu Java 11

Momentan ist nur die Lösung zur "aufgabe7.reactive" enthalten