Maven-Projekt für Java11-Sample-Code
