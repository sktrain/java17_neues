Das neue HTTP-API ist als Incubator-Release ab Java 9 dabei.

Ab Java 11 fester Bestandteil.