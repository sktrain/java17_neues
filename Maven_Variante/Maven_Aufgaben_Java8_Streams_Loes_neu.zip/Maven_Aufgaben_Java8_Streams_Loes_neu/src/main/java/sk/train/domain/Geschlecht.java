package sk.train.domain;

public enum Geschlecht { W, M, D

}
