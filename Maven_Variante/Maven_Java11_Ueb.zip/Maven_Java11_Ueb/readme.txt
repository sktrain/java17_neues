Übungen zu Java 11

(Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom September 2024
+ Jupiter-Dependencies)