package sk.train;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String... args )
    {
        System.out.println( "Hello World! - Java-Version: " + System.getProperty("java.version"));
    }
}
