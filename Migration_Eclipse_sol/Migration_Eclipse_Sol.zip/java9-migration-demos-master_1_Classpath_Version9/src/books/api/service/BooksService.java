package books.api.service;

import java.util.List;

import books.api.entities.Book;
import books.impl.entities.BookEntity;

public interface BooksService {
  Book getBook(int id);
  int createBook(String title, double price);
  List<BookEntity> getAllBooks();
}
