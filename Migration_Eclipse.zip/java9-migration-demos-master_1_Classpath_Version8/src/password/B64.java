package password;

public class B64 {
	
    public static String getBASE64(String s) {  
        if (s == null)  
            return null;  
        return (new sun.misc.BASE64Encoder()).encode(s.getBytes());  
    } 

    // Decode the BASE64 encoded string s
    public static String getFromBASE64(String s) {  
        if (s == null)  
            return null;  
        sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();  
        try {  
            byte[] b = decoder.decodeBuffer(s);  
            return new String(b);  
        } catch (Exception e) {  
            return null;  
        }  
    }  
    // Encrypt the BASE64-encoded string s, that is, perform BASE64 encoding on the string three times
    public static String encryption(String s){
        return B64.getBASE64(B64.getBASE64(B64.getBASE64(s)));
    }
    // Decrypt the BASE64 encoded string s, that is, perform BASE64 decoding on the string three times
//    public static String decryption(String _3b64){
//        return B64.getFromBASE64(B64.getFromBASE64(B64.getFromBASE64(_3b64)));
//    }
    
}