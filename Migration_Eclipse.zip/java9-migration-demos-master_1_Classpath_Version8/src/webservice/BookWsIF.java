package webservice;

import java.util.List;

import javax.jws.WebService;

import books.impl.entities.BookEntity;

@WebService
public interface BookWsIF {
	
	public int createBook(String title, double price);
	
	public List<BookEntity> test();

}