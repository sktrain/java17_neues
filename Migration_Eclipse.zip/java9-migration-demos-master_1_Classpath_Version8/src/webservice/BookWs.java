package webservice;

import java.util.List;

import javax.inject.Inject;
import javax.jws.WebService;

import org.springframework.stereotype.Component;

import books.api.service.BooksService;
import books.impl.entities.BookEntity;

@Component
@WebService(endpointInterface = "webservice.BookWsIF")
public class BookWs implements BookWsIF {
	
	@Inject
	private BooksService bserv;
	
	public int createBook(String title, double price) {
		int id = bserv.createBook(title, price);
		return id;
	}
	
	public List<BookEntity> test() {
		return bserv.getAllBooks();
	}

}
