package books.api.entities;

public interface Book {
  int getId();
  String getTitle();
  double getPrice();
}
