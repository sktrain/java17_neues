module module06_Service {
	exports sk.train.service;
	requires java.logging;
	requires com.google.common;
	//requires guava;	
}