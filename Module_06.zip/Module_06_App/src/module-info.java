module module_06_App {	
	requires java.desktop;
	requires module06_Service;
}