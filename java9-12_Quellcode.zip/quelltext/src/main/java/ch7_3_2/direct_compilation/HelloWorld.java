package ch7_3_2.direct_compilation; 

import java.time.*;

public class HelloWorld 
{
	public static void main(String... args) 
	{
		System.out.println("Hello Execute After Compile");

		System.out.println(LocalDate.now());
	}
}
