package ch6_1.syntax;

/**
 * Beispielprogramm für das Buch "Java – die Neuerungen in Version 9 bis 12"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Person {

    // bewusst minimal :-)
	public Person(String string, int i) 
	{
		
	}
}
