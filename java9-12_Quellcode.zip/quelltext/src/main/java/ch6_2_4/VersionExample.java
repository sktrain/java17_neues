package ch6_2_4;

/**
 * Beispielprogramm für das Buch "Java – die Neuerungen in Version 9 bis 12"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class VersionExample 
{	
	public static void main(final String[] args) 
	{
		var version = Runtime.version();
		
		System.out.println(version);		
		System.out.println("Major: " + version.major());
		System.out.println("Minor: " + version.minor());
		System.out.println("Security: " + version.security());
		System.out.println("Feature: " + version.feature());
		System.out.println("Interim: " + version.interim());
		System.out.println("Update: " + version.update());
		System.out.println("Patch: " + version.patch());
		System.out.println("Build: " + version.build());
		System.out.println("Pre: " + version.pre());
	}	
}

