package ch6_2_5;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Beispielprogramm für das Buch "Java – die Neuerungen in Version 9 bis 12"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class TransferToAndCharsetExample 
{
	public static void main(final String[] args) throws IOException 
	{
		var values = new byte[] { 'A', 'B', 'C', 'D' };
		var is = new ByteArrayInputStream(values);
		var bos = new ByteArrayOutputStream();

		is.transferTo(bos);

		System.out.println(bos.toString());
		System.out.println(bos.toString(StandardCharsets.UTF_16));
	}
}
