module timeclient
{
    requires java.desktop;
        
    requires timeserver;
}