module timeserver
{
    exports com.server;
}