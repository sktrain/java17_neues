module timeclient
{
    requires timeserver;
}