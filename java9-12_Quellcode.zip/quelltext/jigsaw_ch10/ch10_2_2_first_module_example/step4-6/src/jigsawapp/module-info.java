module jigsawapp 
{
	requires services;
}
