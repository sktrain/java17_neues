module services 
{
	exports com.services.api;

	// keine Freigabe von com.services.impl
}
