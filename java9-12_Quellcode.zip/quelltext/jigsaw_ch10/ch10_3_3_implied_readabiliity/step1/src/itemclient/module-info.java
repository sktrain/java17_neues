module itemclient
{
    requires itemfactory;
    requires domainmodel;
}