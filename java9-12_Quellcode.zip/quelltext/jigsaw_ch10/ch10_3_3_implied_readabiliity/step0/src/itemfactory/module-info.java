module itemfactory 
{
    requires java.logging;

    requires domainmodel;
    
    exports com.itemfactory;
}