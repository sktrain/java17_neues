module itemclient
{
    requires itemfactory;
}