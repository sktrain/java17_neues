module itemfactory 
{
    requires java.logging;

    requires transitive domainmodel;
    
    exports com.itemfactory;
}