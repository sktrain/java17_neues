module timeserver
{
    requires java.logging;
    
    exports com.server;
}