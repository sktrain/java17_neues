module privatetimeclient
{
    requires timeserver;
}