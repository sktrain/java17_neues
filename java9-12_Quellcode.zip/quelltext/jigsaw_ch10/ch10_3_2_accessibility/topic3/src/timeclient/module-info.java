module timeclient
{    
    requires timeserver;
    
    exports com.client;
}