module timeserver
{
    exports com.server;
    exports com.server.internal to privatetimeclient;
}