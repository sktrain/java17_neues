module two_automatic_modules_example 
{     
    requires myjarneedsguava;
    requires com.google.common;
}