module auto_unnamed_modules_example 
{ 
    requires myjarneedsguava;
}