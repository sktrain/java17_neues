module automatic_module_example 
{ 
    //requires guava;
    requires com.google.common;  // ab guava 24.0-jre
}