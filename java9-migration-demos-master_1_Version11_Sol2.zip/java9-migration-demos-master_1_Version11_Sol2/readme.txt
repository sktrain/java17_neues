Da ab Java11 Jax-Ws nicht mehr Teil der SE:

Metro Jax-WS-RI: jax-ws-ri-2.3.1  Jars hinzugefügt,
diese liegen im Projektordner lib_jaxws.
(Die bisherigen anderen Jars liegen im Projektordner lib)

Diese Version funktioniert für Java 11.

Da die ursprünglich verwendete javassist-3.20.0-GA.jar einen IllegalAccess verursacht, 
wird diese durch eine aktuelle Variante ersetzt: javassist-3.28.0-GA.jar

