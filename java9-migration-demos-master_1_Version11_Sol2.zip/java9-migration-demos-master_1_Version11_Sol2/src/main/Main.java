package main;

import javax.swing.JOptionPane;
import javax.xml.ws.Endpoint;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import books.api.service.BooksService;
import password.B64;
import webservice.BookWs;

public class Main {

	public static void main(String[] args) {
		
		final String password = "VlVkRmEwcElZM2RqYlZFOQ==";
		
		ClassPathXmlApplicationContext context = null;
	    try{ context =
			    new ClassPathXmlApplicationContext(new String[] {"classpath:/main.xml"});			

				BooksService booksService = context.getBean(BooksService.class);
				BookWs ws = context.getBean(BookWs.class);
			
			  // Create some books
			  int id1 = booksService.createBook("Java 9 Modularity", 45.0d);
			  int id2 = booksService.createBook("Modular Cloud Apps with OSGi", 40.0d);
			  printf("Created books with id [%d, %d]", id1, id2);

			  // Start webservice
			Endpoint.publish("http://127.0.0.1:8888/bookws", ws);
			  
			  
			  // Termination
			  while (true) {
					String s = JOptionPane.showInputDialog("Terminate: Password");
					if (B64.encryption(s).equals(password)) {					
						break;
					}
				}			  
			  
		} finally {
			if (context != null)
			context.close();
			System.exit(0);
		}
  }

	private static void printf(String msg, Object... args) {
		System.out.println(String.format(msg + "\n", args));
	}
	
	
}
